# Daily Tasks Manager — Source Code

هذه الحزمة تحتوي على المصدر الكامل:

- `artifacts/daily-tasks-mobile`: تطبيق Expo للجوال.
- `artifacts/daily-tasks-manager`: تطبيق الويب.
- `artifacts/api-server`: خادم Express وواجهات API.
- `lib/api-spec`: عقود OpenAPI.
- `lib/api-client-react` و`lib/api-zod`: ملفات API المولدة.
- `lib/db`: مخططات قاعدة البيانات.

## التجهيز

```bash
pnpm install
pnpm --filter @workspace/api-spec run codegen
```

## فحص المصدر

```bash
pnpm --filter @workspace/api-server run typecheck
pnpm --filter @workspace/daily-tasks-manager run typecheck
pnpm --filter @workspace/daily-tasks-mobile run typecheck
```

## التشغيل

```bash
pnpm --filter @workspace/api-server run dev
pnpm --filter @workspace/daily-tasks-manager run dev
pnpm --filter @workspace/daily-tasks-mobile run dev
```

ستحتاج إلى إعداد PostgreSQL وClerk ومتغيرات البيئة الخاصة بك عند التشغيل خارج Replit.

ملفات الأسرار و`.env` غير مضمنة. كما تم استبعاد `node_modules` وملفات البناء؛ يتم إنشاؤها مجددًا عبر `pnpm install` وأوامر البناء.
