import { createInsertSchema } from "drizzle-zod";
import { boolean, date, index, integer, jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const taskLinkSchema = z.object({
  label: z.string().min(1),
  url: z.string().url(),
});

export type TaskLink = z.infer<typeof taskLinkSchema>;

export const taskFollowUpSchema = z.object({
  id: z.number().int(),
  title: z.string().min(1),
  completed: z.boolean(),
  dueDate: z.string().nullable(),
});

export type TaskFollowUp = z.infer<typeof taskFollowUpSchema>;

export const taskSubtaskSchema = z.object({
  id: z.number().int(),
  title: z.string().min(1),
  completed: z.boolean(),
});

export type TaskSubtask = z.infer<typeof taskSubtaskSchema>;

export const tasksTable = pgTable(
  "daily_tasks",
  {
    id: integer("id").generatedAlwaysAsIdentity().primaryKey(),
    taskDate: date("task_date", { mode: "string" }).notNull(),
    ownerId: text("owner_id"),
    category: text("category").notNull(),
    title: text("title").notNull(),
    notes: text("notes"),
    priority: text("priority").notNull().default("medium"),
    recurrence: text("recurrence"),
    dueDate: date("due_date", { mode: "string" }),
    subtasks: jsonb("subtasks").$type<TaskSubtask[]>().notNull().default([]),
    completed: boolean("completed").notNull().default(false),
    links: jsonb("links").$type<TaskLink[]>().notNull().default([]),
    followUps: jsonb("follow_ups").$type<TaskFollowUp[]>().notNull().default([]),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => ({
    ownerTaskDateIdx: index("daily_tasks_owner_task_date_idx").on(table.ownerId, table.taskDate),
  }),
);

export const insertTaskSchema = createInsertSchema(tasksTable).omit({
  createdAt: true,
  updatedAt: true,
});

export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasksTable.$inferSelect;